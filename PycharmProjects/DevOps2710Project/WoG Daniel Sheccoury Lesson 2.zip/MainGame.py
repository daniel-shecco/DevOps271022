from Live import *

my_game = WorldOfGames()


