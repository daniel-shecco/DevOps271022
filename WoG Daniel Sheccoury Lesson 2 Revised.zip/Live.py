class WorldOfGames:
    def __init__(self):
        self.welcome()
        self.load_game()




    def welcome(self):
        """This Function Welcomes the player to the game and requires a string input"""

        name = ''
        while True:

            try:
                name = str(input('Hello what is your name? ').title())
                if name.isalpha():
                    print(f'Hello {name} and welcome to WoG!\n')
                    break

            except:
                if name.isnumeric():
                    print('Please type a name with letters from A-Z')





    def load_game(self):
        """ A function that asks the player to choose a game.
        Takes an integer from 1-3 and asks a player to choose a difficulty between 1-5"""



        while True:


            game_of_choice = input('''Please Choose a game to play \n
                            1. Memory Game - a sequence of numbers will appear for 1 second and you have to guess it back \n
                            2. Guess Game - guess a number and see if you chose like the computer\n
                            3. Currency Roulette - try and guess the value of a random amount of USD in ILS\n
                            ''')


            if game_of_choice.isnumeric():
                game_of_choice = int(game_of_choice)
            if game_of_choice in range(1, 4):
                break
            else:
                print('Not a number between 1-3')

        while True:

            game_difficulty_choice = input('Please choose a game difficulty between 1-5 ')
            if game_difficulty_choice.isnumeric():
                game_difficulty_choice = int(game_difficulty_choice)
            if game_difficulty_choice in range(1, 6):
                print(f'your game difficulty of choice is:  {game_difficulty_choice}')
                break
            else:
                print('Not a number between 1-5. Please choose your difficulty')






















        #     if game_of_choice.isalpha():
        #         print('Type a number between 1-3')
        #         self.load_game()
        #     elif game_of_choice not in range(0, 4):
        #         print('Type a number between 1-3')
        #         self.load_game()
        #
        #     game_of_choice.isnumeric()
        #
        # else:
        #     game_of_choice is in range(0, 4)



            #
            # if game_difficulty_choice in range(0, 6):
            #
            #             break
            #






            # elif game_of_choice not in range(0, 4):
            #     print('Type a number between 1-3')
            #


























