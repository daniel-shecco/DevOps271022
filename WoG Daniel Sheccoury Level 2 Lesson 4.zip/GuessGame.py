import random
import Live


secret_number = 0
def generate_number():
    """ A function that generates a secret random number """

    secret_number = random.randint(1, Live.game_difficulty_choice)
    return secret_number


user_guess = 0

def get_guess_from_user():
    """A function that takes an input from the user guessing the secret number """
    while True:
        user_guess = input("Please choose a number between 1 and the game difficulty you chose in the previous step \n")
        if user_guess.isnumeric():
            user_guess = int(user_guess)
            return user_guess



def compare_results():
    """A function that compares if the list that the user guessed is the same as the secret number"""
    if secret_number == user_guess:
        print('True')

    else:
        print('False')



def play_guess():
    """A function that calls the other functions to play the game"""
    generate_number()
    get_guess_from_user()
    compare_results()
