import requests
import Live
import random

""" Create a random range for the amount parameter of the currency API """
random_currency_number = random.randrange(1, 100)


"""Calls the converted result of USD into Shekels"""
url = f'https://api.exchangerate.host/convert?from=USD&to=ILS&amount={random_currency_number}'

response = requests.get(url)
# print(response.json()['result'])
currency_rate = response.json()['result']


def get_guess_from_user():
    """1. A function that creates an interval from the api currency data
    2. Requests the user's guess for the correct amount of Shekels converted from USD
    3. Checks if the user's guess is in the interval and declares if the user won or lost accordingly"""
    d = Live.game_difficulty_choice
    t = currency_rate
    interval_1 = round(int((t - (5 - d))))
    interval_2 = round(int((t + (5 - d))))
    print(interval_1,interval_2)



    while True:
        currency_guess = input(f'Please guess the amount in ILS of this {random_currency_number} USD number ')
        if currency_guess.isdigit():
            currency_guess = int(currency_guess)
            break

    if currency_guess in range(interval_1, interval_2):
        won = 'You Won'
        print(won)

    else:
        lost = 'Loser'
        print(lost)




def play_currency():
    """A function to play the game"""
    get_guess_from_user()







