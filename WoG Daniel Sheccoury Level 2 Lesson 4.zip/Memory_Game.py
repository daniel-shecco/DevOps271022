import random
import time
import Live

#### Create a sequence list ####
sequence_list = []

for i in range(1, 101):
        sequence_list.append(str(i))

def generate_sequence():
        """A function to generate a random sequnce of numbers depending on the difficulty the user has chosen
in the previous step, shows them to the user and disappear after 0.7 seconds """

        global sequence
        sequence = random.sample(sequence_list, Live.game_difficulty_choice)

        print(sequence)
        time.sleep(0.7)
        print("\n time is up, \n\n\n")



def get_list_from_user():
        """a function that gets the user list of numbers they remember from the sequence showed to the user in
The previous step """

        global user_list

        while True:
                user_list = []
                user_list = input('Please enter the list of numbers shown to you in the correct order ').split()
                if len(user_list) >= 1:
                        break


def is_list_equal():
        """A function that compares if the list that the user guessed is the same as the sequence
        (Checks number by number and outputs if the guess is correct or not"""

        for x, y in zip(sequence, user_list):
                if x == y or y == x:

                        print(f'{user_list} is Correct')


                else:
                        print(f'{user_list} are the wrong numbers, the correct numbers are: {sequence}')


def play_memory():
        """A function that calls the other functions to play the game"""
        generate_sequence()
        get_list_from_user()
        is_list_equal()




















